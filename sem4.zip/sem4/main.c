#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
        char name[30];
        int age;
        float gpa;
};
typedef struct Student Student;

/*
  Нийлүүлэн эрэмбэлэх аргын цааш хуваагдах ёсгүй хэмжээ
 */
#define CUTOFF 10

/*
  a, b хаяганд хадгалагдсан сурагчдыг нэрээр жиших функц.
  a->name, b->name-ээс их бол -1, тэнцүү бол 0, бага бол 1-ийг буцаана.

*/
int nereer(const Student *a, const Student *b)
{
    int cmp = strcmp(a->name, b->name);
    if (cmp < 0) {
        return -1;
    } else if (cmp > 0) {
        return 1;
    } else {
        return 0;
    }
}

/*
  a, b хаяганд хадгалагдсан сурагчдыг насаар нь жиших функц.
  a->age, b->age-ээс их бол -1, тэнцүү бол 0, бага бол 1-ийг буцаана.
*/
int nasaar(const Student *a, const Student *b)
{
    if (a->age < b->age) {
        return -1;
    } else if (a->age > b->age) {
        return 1;
    } else {
        return 0;
    }
}

/*
  a, b хаяганд хадгалагдсан сурагчдыг голчоор  нь жиших функц.
  a->gpa, b->gpa-ээс их бол -1, тэнцүү бол 0, бага бол 1-ийг буцаана.
*/
int golchoor(const Student *a, const Student *b)
{
    if (a->gpa < b->gpa) {
        return -1;
    } else if (a->gpa > b->gpa) {
        return 1;
    } else {
        return 0;
    }
}


/*
  Оруулан эрэмбэлэх функц.
  Жиших үйлдлийг less функцэн заагчийг ашиглан хийнэ.
  Уг функц нь эрэмбэлэхдээ a хүснэгтийн lo-оос
  hi завсыг л зөвхөн эрэмбэлнэ.
*/
void insertion_sort(Student a[],
                    int lo, int hi,
                    int (*less)(const Student *, const Student *))
{
        /* функцийг гүйцээ */
    for (int i = lo + 1; i <= hi; i++) {
        Student tmp = a[i];
        int j = i - 1;
        while (j >= lo && less(&tmp, &a[j])) {
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = tmp;
    }
}

/*
  Нийлүүлсэн эрэмбэлэх аргын mege үйлдэл.
  Уг функц нь a хүснэгтэд [lo; mid], [mid+1; hi] завсарт
  эрэмбэлэгдсэн хүснэгтийг нийлүүлэн [lo; hi] завсарт эрэмбэлэгдсэн хүснэгт болгоно.
  aux хүснэгт нь нэмэлтээр ашиглах хүснэгт. Оюутнуудыг хооронд нь жишихдээ less функцэн
  заагчийг ашиглана.
*/
void merge(Student a[],
           Student aux[],
           int lo,
           int mid,
           int hi,
           int (*less)(const Student *, const Student *))
{
        /* функцийг гүйцээ */
    for (int k = lo; k <= mid; k++) {
        aux[k] = a[k];
    }
    int i = lo, j = mid+1;
    for (int k = lo; k <= hi; k++) {
        if (i > mid) {
            a[k] = aux[j++];
        } else if (j > hi) {
            a[k] = aux[i++];
        } else if (less(&aux[j], &aux[i])) {
            a[k] = aux[j++];
        } else {
            a[k] = aux[i++];
        }
    }
}


/*
  Нийлүүлсэн эрэмбэлэх функц.
  hi - lo <= CUTOFF бол оруулан эрэмбэлэх аргыг хэрэглэнэ.
  Жиших үйлдлийг less функцэн заагчийг ашиглан хийнэ.
  Уг функц нь merge, insertion_sort функцүүдийг дуудан ашиглах ёстой.
*/
void mergesort(Student a[],
               Student aux[],
               int lo,
               int hi,
               int (*less)(const Student *, const Student *))
{
        /* функцийг гүйцээ */
    if (hi <= lo) {
        return;
    }
    if (hi - lo <= CUTOFF) {
        insertion_sort(a, lo, hi, less);
        return;
    }
    int mid = lo + (hi - lo) / 2;
    mergesort(a, aux, lo, mid, less);
    mergesort(a, aux, mid+1, hi, less);
    merge(a, aux, lo, mid, hi, less);
}

int main()
{
        FILE *fin = NULL;
        fin = fopen("myinput.txt", "r");
        if (!fin) {
                printf("input file error!\n");
                exit(-1);
        }
        int i, n;
        fscanf(fin, "%d", &n);
        Student *a, *aux;
        a = (Student *) malloc(sizeof(Student) * n);
        aux = (Student *) malloc(sizeof(Student) * n);
        for (i = 0; i < n; i++) {
                fscanf(fin, "%s%d%f", a[i].name, &a[i].age, &a[i].gpa);
        }
        fclose(fin);
        mergesort(a, aux, 0, n - 1, nereer);
        for (i = 0; i < n; i++)
                printf("%3.1f\t%d\t%s\n", a[i].gpa, a[i].age, a[i].name);
        printf("\n");
        mergesort(a, aux, 0, n - 1, nasaar);
        for (i = 0; i < n; i++)
                printf("%3.1f\t%d\t%s\n", a[i].gpa, a[i].age, a[i].name);
        printf("\n");
        mergesort(a, aux, 0, n - 1, golchoor);

        for (i = 0; i < n; i++)
                printf("%3.1f\t%d\t%s\n", a[i].gpa, a[i].age, a[i].name);

        return 0;
}
