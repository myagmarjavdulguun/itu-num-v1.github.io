#include "GL/freeglut.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <math.h>
using namespace std;

struct Point {
    float x, y, z;
};
struct Triangle {
    int p1, p2, p3;
};

vector<Point> points;
vector<Triangle> triangles;

// Rotation amounts
static GLfloat xRot = -90.0f;
static GLfloat yRot = 0.0f;
static float dist = -5.0f;

void makeDragon() {
    ifstream file("C:\\Users\\user\\Desktop\\computer_graphics\\lab9\\dragon.obj");
    if(!file.is_open()) {
        cerr << "Failed to open file" << endl;
    }

    string line;
    while(getline(file, line)) {
        istringstream iss(line);
        string token;

        if(line[0] == 'v') {
            Point p;
            iss >> token >> p.x >> p.y >> p.z;
            points.push_back(p);
        } else if(line[0] == 'f') {
            Triangle t;
            iss >> token >> t.p1 >> t.p2 >> t.p3;
            triangles.push_back(t);
        }
    }
}

void ChangeSize(int w, int h)
{
    GLfloat fAspect;

    if(h == 0)
        h = 1;

    glViewport(0, 0, w, h);

    fAspect = (GLfloat)w/(GLfloat)h;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(35.0f, fAspect, 0.1, 40.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void SetupRC()
{
    makeDragon();

    GLfloat ambient[] = {0.0, 0.0, 0.0, 1.0};
    GLfloat diffuse[] = {1.0, 1.0, 1.0, 1.0};
    GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
    GLfloat position[] = {0.0, 0.0, 100.0, 0.0};

    GLfloat lmodel_ambient[] = {0.2, 0.2, 0.2, 1.0};
    GLfloat local_view[] = {0.0};

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, position);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);

    glFrontFace(GL_CW);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_AUTO_NORMAL);
    glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST);

    glClearColor(0.5f, 0.5f, 0.5f, 0.5f);
    glutPostRedisplay();
}

void SpecialKeys(int key, int x, int y)
{
	if(key == GLUT_KEY_UP)
		xRot-= 5.0f;

	if(key == GLUT_KEY_DOWN)
		xRot += 5.0f;

	if(key == GLUT_KEY_LEFT)
		yRot -= 5.0f;

	if(key == GLUT_KEY_RIGHT)
		yRot += 5.0f;

        xRot = (GLfloat)((const int)xRot % 360);
        yRot = (GLfloat)((const int)yRot % 360);

	glutPostRedisplay();
}

void RenderScene(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    GLfloat mat_ambient[] = { 0.24725f, 0.1995f, 0.0745f, 1.0f };
    GLfloat mat_diffuse[] = { 0.75164f, 0.60648f, 0.22648f, 1.0f };
    GLfloat mat_specular[] = { 0.628281f, 0.555802f, 0.366065f, 1.0f };
    GLfloat mat_shininess[] = { 51.2f };
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

    glLoadIdentity();
    glPushMatrix();

        glTranslatef(0.0f, 0.0f, dist);
        glRotatef(xRot, 1.0f, 0.0f, 0.0f);
        glRotatef(yRot, 0.0f, 0.0f, 1.0f);

        for(int i = 0; i < triangles.size(); i++) {
            glBegin(GL_TRIANGLES);

                float v1x = points[triangles[i].p1 - 1].x - points[triangles[i].p2 - 1].x;
                float v1y = points[triangles[i].p1 - 1].y - points[triangles[i].p2 - 1].y;
                float v1z = points[triangles[i].p1 - 1].z - points[triangles[i].p2 - 1].z;

                float v2x = points[triangles[i].p1 - 1].x - points[triangles[i].p3 - 1].x;
                float v2y = points[triangles[i].p1 - 1].y - points[triangles[i].p3 - 1].y;
                float v2z = points[triangles[i].p1 - 1].z - points[triangles[i].p3 - 1].z;

                float nvx = v1y*v2z - v2y*v1z;
                float nvy = v1z*v2x - v2z*v1x;
                float nvz = v1x*v2y - v2x*v1y;

                float nvl = sqrt(nvx*nvx + nvy*nvy + nvz*nvz);

                glNormal3f(nvx/nvl, nvy/nvl, nvz/nvl);

                glVertex3f(points[triangles[i].p1 - 1].x, points[triangles[i].p1 - 1].y, points[triangles[i].p1 - 1].z);
                glVertex3f(points[triangles[i].p2 - 1].x, points[triangles[i].p2 - 1].y, points[triangles[i].p2 - 1].z);
                glVertex3f(points[triangles[i].p3 - 1].x, points[triangles[i].p3 - 1].y, points[triangles[i].p3 - 1].z);
            glEnd();
        }

    glPopMatrix();

    glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y) {
    if(key == 27) {
        exit(0);
    }
    if(key == 'w') {
        dist += 0.1;
    }
    if(key == 's') {
        dist -= 0.1;
    }

    glutPostRedisplay();
}


int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Modeling with Quadrics");
    glutReshapeFunc(ChangeSize);
    glutSpecialFunc(SpecialKeys);
    glutDisplayFunc(RenderScene);
    glutKeyboardFunc(Keyboard);
    SetupRC();
    glutMainLoop();

    return 0;
}


