package lab5;

public class Client {
	private String name;
	private int servedNo;
	private String[] services = new String[5];
	private int serviceNo;
	private int payment;
	
	public Client() {
		name = "";
		servedNo = 0;
	}
	public Client(String name) {
		this.name = name;
		servedNo = 0;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getServedNo() {
		return servedNo;
	}
	public int getPayment() {
		return payment;
	}
	public void paid() {
		payment = 0;
	}
	public void served(String service) {
		for(int i = 0; i < 5; i++) {
			if(Salon.services[i] == service) {
				services[serviceNo] = service;
				serviceNo++;
				payment += Salon.prices[i];
			}
		}
	}
	public void pay() {
		System.out.println(name);
		for(int i = 0; i < serviceNo; i++) {
			System.out.println(services[i]);
		}
		System.out.println(payment);
		serviceNo = 0;
	}
	public void addServedNo() {
		servedNo++;
	}
}
