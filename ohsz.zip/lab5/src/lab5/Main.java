package lab5;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Salon mySalon = new Salon("Sunny");
		mySalon.registerClient("Цэцэгээ");
		mySalon.clientType("Цэцэгээ");
		mySalon.serve("Цэцэгээ", 0);
		mySalon.serve("Цэцэгээ", 1);
		mySalon.serve("Цэцэгээ", 3);
		mySalon.payment("Цэцэгээ");
		
		mySalon.registerClient("Rose");
		mySalon.clientType("Rose");
		mySalon.serve("Rose", 4);
		mySalon.payment("Rose");
	}

}
