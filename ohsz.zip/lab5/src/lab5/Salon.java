package lab5;

public class Salon {
	private String name;
	private Client[] clients = new Client[100];
	private static int clientNo = 0;
	static String services[] = {"хумсны хэлбэр засах", "хумс цэвэрлэх", "хумс будах", "хумсан дээр саа тавих", "хумс бэхжүүлэх"};
	static int prices[] = {10000, 5000, 10000, 9000, 15000};
	
	public Salon() {
		name = "";
	}
	public Salon(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void registerClient(String name) {
		clients[clientNo] = new Client(name);
		clientNo++;
	}
	public void serve(String name, int no) {
		for(int i = 0; i < clientNo; i++) {
			if(clients[i].getName() == name) {
				clients[i].served(services[no]);
			}
		}
	}
	public void clientType(String name) {
		for(int i = 0; i < clientNo; i++) {
			if(clients[i].getName() == name) {
				if(clients[i].getServedNo() == 0)
					System.out.println(name+" шинэ үйлчлүүлэгч");
				else if(clients[i].getServedNo() > 10)
					System.out.println(name+" алтан үйлчлүүлэгч");
				else if(clients[i].getServedNo() > 5)
					System.out.println(name+" найдвартай үйлчүүлэгч");
			}
		}
	}
	public void payment(String name) {
		for(int i = 0; i < clientNo; i++) {
			if(clients[i].getName() == name) {
				clients[i].pay();
				if(clients[i].getServedNo() == 0)
					System.out.println(name+" шинэ үйлчлүүлэгч тул хямдарсан үнэ "+clients[i].getPayment()*80.0/100.0);
				else if(clients[i].getServedNo() > 10)
					System.out.println(name+" алтан үйлчлүүлэгч тул хямдарсан үнэ "+clients[i].getPayment()*90.0/100.0);
				else if(clients[i].getServedNo() > 5)
					System.out.println(name+" найдвартай үйлчүүлэгч тул хямдарсан үнэ "+clients[i].getPayment()*95.0/100.0);
				clients[i].addServedNo();
				clients[i].paid();
			}
		}
	}
}
