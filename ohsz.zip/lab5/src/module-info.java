/**
 * 
 */
/**
 * @author user
 *
 */
module lab5 {
}